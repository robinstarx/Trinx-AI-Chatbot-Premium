

class Solution:
	# def __init__():
	# 	None

	def count_number_arr(self,arr):
		hash_table = {}
		count = 0
		for i in range(len(arr)):
			if arr[i] in hash_table:
				hash_table[arr[i]] +=1
			else:
				hash_table[arr[i]] = 1
		print(hash_table)
		max_num = 0
		max_val = 0
		min_val = 0
		min_num = 0

		for num in hash_table:
			if hash_table[num] > max_num:
				max_val = num
				max_num = hash_table[num]
			elif hash_table[num] < max_num:
				min_val = num
				min_num = hash_table[num]
	def count_alphabet(self,s):
		hash_t = {}

		for i in range(25):
			hash_t[chr(65+i)] = 0

		for alpha in s:
			if alpha in hash_t:
				hash_t[alpha] +=1
			else:
				hash_[alpha]+=1
		print(hash_t)

	def maxFrequency(self,nums,k):

		nums.sort()
		l, r = 0, 0
		res, total = 0, 0
		def max_val(n1,n2):
			return n1 if n1>n2 else n2 

		while r < len(nums):
			total += nums[r]
			while nums[r] * (r - l + 1) > total + k:
				total-=nums[l]
				l+=1
			res = max_val(res,r - l + 1)
			r+=1
		print(res)
		return res

sol = Solution()
nums = [1,1,2,2,9,3]
# sol.count_number_arr(nums)
# s = "MALAYALAM"
# sol.count_alphabet(s)
sol.maxFrequency(nums,2)




