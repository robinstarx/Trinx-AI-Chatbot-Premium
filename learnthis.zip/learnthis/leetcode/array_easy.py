import math

class ArrayEasy:
	def __init__(self):
		print("Array Easy Problem")

	def largest_element(self, nums):
		l_val = float('-inf')
		for i in range(len(nums)):
			if nums[i] > l_val:
				 l_val = nums[i]
		return l_val


	def second_largest_element(self, nums):
		l_val = nums[0]
		s_val =  float('-inf')

		for i in range(len(nums)):
			if nums[i] > l_val:
				s_val = l_val
				l_val = nums[i]
			elif nums[i] < l_val  and nums[i] > s_val:
				s_val = nums[i]
		return s_val

	def is_nums_sorted(self, nums, n):
		if n == 1:
			print("Sorted")
			return 
		is_sorted = False

		for i in range(n-1):
			if nums[i] >  nums[i + 1]:
				print("this is numsay is not storted")
				return 
		print("This numsay is s")
		return



	def search(self, nums, val):

		for num in nums:
			if num == val:
				print(f"found the value")
		print("There is no value")
		return 
	
	def remove_duplicate(self,nums):
		k = 0
		for i in range(1,n):
			if nums[i] != nums[i-1]:
				nums[k] = nums[i]
				k+=1



	def rotation_nums(self, nums, dir):

		if dir == "l":
			temp = nums[0]
			for i in range(1,len(nums)):
				nums[i-1] = nums[i]
			nums[-1] = temp

		elif dir =='r':
			temp = nums[-1]
			for i in range(len(nums)-1,0,-1):
				nums[i] = nums[i-1]
			nums[0] = temp

	def reverse_nums(self, nums, start, end):
		
		while start < end:
			nums[start], nums[end] = nums[end], nums[start]
			
			start+=1
			end-= 1

	def rotate_nums_by_k(self, nums, k, dir):
		n = len(nums)
		# T: O(N)+O(k)+ O(K-N) == O(N)
		# S: O(1)
		k%=n # it for lowering roation if k = 9 and n = 7, 9 % 7 = 2 
		if k == 0:
			return 
		
		if dir == 'r':
			self.reverse_nums(nums, 0, n - 1)
			self.reverse_nums(nums, 0, k - 1)
			self.reverse_nums(nums, k, n - 1 )
		elif dir == 'l':
			self.reverse_nums(nums, 0, k - 1)
			self.reverse_nums(nums, k, n - 1)
			self.reverse_nums(nums, 0, n-1)
		return
	
	def move_zero(self,nums):
		n = len(nums)
		k = 0
		if n == 0:
			return 
		for i in range(n):
			if nums[i] != 0:
				nums[k], nums[i] = nums[i], nums[k]
				k+=1
	def u_two_sorted__arr(self, nums1, nums2):
		n, m = len(nums1),len(nums2)

		i, j = 0, 0

		s = set()
		union = []
		nums_len = 0
		# T: O(N1+N2) because visting the every element at least one time, so at the end of the loop the TC will O(N)+O(N)
		# S: O(N)
		while i < n and j < m:

			if nums1[i] < nums2[j]:
				if not union or union[-1] !=nums1[i]:
					union.append(nums1[i])
					i+=1

			elif nums2[j] < nums1[i]:
				if not union or union[-1] != nums2[j]:
					union.append(nums2[j])
					j+=1
			else:
				if not union or union[-1]!=nums1[i]:
					union.append(nums1[i])
					i+=1
					j+=1

		while i < n:
			if not union or union[-1] !=nums1[i]:
				union.append(nums1[i])
				i+=1

		while j < m:
			if not union or union[-1] !=nums2[j]:
				union.append(nums2[j])
				j+=1
		print(union)

	def intersection_two_sorted_arr(self, nums1, nums2):

		n = len(nums1)
		m = len(nums2)
		i, j  = 0, 0
		res = []
		while i < n and j < m:
			if nums1[i] < nums2[j]:
				i+=1
			elif nums2[j] < nums1[i]:
				j+=1
			else:
				res.append(nums1[i])
				i+=1
				j+=1
		print(res)





	def missing_num(self, nums):
		n = len(nums) + 1
		hash = [0] * (n - 1)
		print(hash)


		#T:O(N)
		#S:O(1)
		# n = len(nums) + 1

		# total_sum = sum(nums)
		# expSum = n * (n + 1) // 2
		# print(expSum)
		# print(expSum - total_sum)		

		#Bit manupulation:

	def ones_consecutive(self,nums):

		max_val = 0
		cnt = 0

		for num in nums:
			if num == 1:
				cnt+=1
			else:
				cnt = 0
			max_val= max(max_val, cnt)

		print(max_val)

	def num_appear_ones(self, nums):
		# hash_map = {}

		# for i in range(len(nums)):
		# 	if nums[i] in hash_map:
		# 		hash_map[nums[i]]+=1
		# 	else:
		# 		hash_map[nums[i]] = 1
		# for num,cnt in enumerate(hash_map):
		# 	if cnt == 1:
		# 		print(num)
		xor = 0
		for num in nums:
			xor^=num


		print(f"The number which appear ones: {xor}")

		return xor

	def longest_subbarray(self, nums, k):

		sum_ = 0
		max_val = 0
		cnt = 0
		n = len(nums)

		for i in range(n):
			sum_ += nums[i]

			if sum_ <= k:
				cnt+=1
				max_val = max(max_val, cnt)
			else:
				cnt = 0
				sum_-=nums[i]

		print(max_val)




# nums1 = [1, 2, 3, 4, 5 ,6, 8]
# nums2 = [2, 4, 5, 6, 8, 9, 10, 20]

sol = ArrayEasy()

# res1 = sol.largest_element(nums,"O")
# print(res1)
# res2 = sol.second_largest_element(nums)
# print(res2)
# sol.is_nums_sorted(nums, len(nums)) 

# sol.rotate_nums_by_k(nums,2,"l")
# sol.move_zero(nums)
# res=sol.u_two_sorted__arr(nums1, nums2)
# sol.intersection_two_sorted_arr(nums1, nums2)

# nums = [1, 1, 0, 1, 1, 1]
# sol.missing_num(nums)

# sol.ones_consecutive(nums)
# nums = [4,4,1,2,2,0,0]
# sol.num_appear_ones(nums)


#longest_subarray
# nums = [1, 9, 4, 8, 3, 4, 9, 4, ,11, 1,1] 

# [4,8,3,]
k =  19
# sol.longest_subbarray(nums, k)

print(89//10)
print(89%10)