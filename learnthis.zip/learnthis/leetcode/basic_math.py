import math


class Solution:

  def __init__(self):
    print(f"Here is the Basic Math Problem")

  #Find the Count of Digit
  def count_digit(self,num):
      count = 0
      dup = num
      while num > 0:
        count+=1 
        num//=10
      print(f"The number  of this {dup} is {count}")
  
  def count_digit_optimal(self,num):
    print(f"{num} of this {int(math.log10(num)+1)}")
  #Input:12341
  #Output:5
  
  #Reverse the given number
  #Time complextiy:O(n/10)
  def rev_number(self,num):
      rev = 0
      dup = num
      
      while num > 0:
        last_d = num%10
        rev = (rev*10) + last_d
        num = num //10
      print(f"This reverse of this {dup} is {rev}")
      print()
    #Input:3243900
    #Output:93423
  def palindrom_number(self,num):
    dup = num
    rev = 0
    
    while num > 0:
      last_d = num%10
      rev = rev *10 + last_d
      num = num//10
    print()
    print(dup,rev,"is it?" )
    print()
    
  #Find Amstrong_number -
  def amstrong_num(self,num):
    
    cube_sum = 0
    dup = num
    
    while num > 0:
      last_n = num%10
      cube_sum+=last_n**3  
      num = num//10
    print(f"Amstong number")
    
    if cube_sum == dup:
      print(f"This is Amstong number {cube_sum}")
    else:
      print(f"This is not a Amstong number {cube_sum}")
    print()
  #Input:153
  #Output:153
  
  #Divsible digit
  #O(N)
  def divisible_by_N(self,num):
  
    arr = []
    for i in range(1,num+1):
      if num%i == 0:
        arr.append(i)
    print("This are the divisible number:")
    print(arr)
  #Time complextiy : O(sqrt(num))  
  def divisible_by_N_Optimal(self,num):
    
    arr = []
    for i in range(1,int(math.sqrt(num))+1):
      if num%i == 0:
        arr.append(i)
        if (num//i) != i:
          arr.append(num//i)
    print("This are the divisible number:")
    print(sorted(arr))
    print()
  #Input: 12
  #Output [1,12,2,6,3,4,]
  
  #Find the prime number
  #Time complextiy : O(N)  
  def prime_num(self, num):
      count = 0
      for i in range(1,num+1):
        if num%i==0:
          count+=1
      if count == 2:
        print("This is Prime number ")
      else:
        print("This is Not Prime number ")
  #Time complextiy : O(sqrt(n))
  def prime_num_optimal(self,num):
    dup = num
    count = 0
    for i in range(1,int(math.sqrt(num))+1):
      if num%i==0:
        count+=1
        if num//i!=i:
          count+=1
          
    if count == 2:
      print(f"This is Prime number {dup}")
    else:
      print(f"This is Not Prime number {dup} ")
      print()
  #Input:5
  #Output:True
  
  #Find the Greatest Common divsible
  #Time complextiy : O(min(num))    
  def GCD(self, N1, N2):
    
    max_v = min(N1,N2)
    gcd = 1
    a = N1 

    
    b = N2
    
    for i in range(min(N1,N2),1,-1):
      if N1%i==0 and N2%i==0:
        gcd=i
    
    print(f"This is the GCD of this two numer {a},{b}")
    print(f"GCD({a},{b}):{gcd} ")
    
  #Time complextiy : O(log_pi(a%b))
  def GCD_Optimal(self,a,b):
    gcd = 1
    N1=a
    N2=b
    while a > 0 and b > 0:
      if a > b:

        a = a % b
      else:
        b = b % a
    
    if a == 0:
        gcd = b 
    else:
      gcd = a
    print(f"This is the GCD of this two numer {N1},{N2}")
    print(f"GCD({N1},{N2}):{gcd} ")
    
if __name__ == "__main__":
  sol = Solution()
  num = 5
  sol.count_digit(12341)
  sol.count_digit_optimal(12341)
  sol.rev_number(12200)
  sol.divisible_by_N(36)
  sol.palindrom_number(12321)
  sol.divisible_by_N_Optimal(12)
  sol.prime_num(5)
  sol.prime_num_optimal(34)
  sol.GCD_Optimal(20,15)
  sol.GCD_Optimal(20,15)
