

class Solution:

	#Time Complexity : O(N)
	#Space Complexity : O(N)
	#Forward Trackig
	def n_to_1(self,N):
		if N < 1:
			return  
		print(N,end=",")
		self.n_to_1(N - 1)


	#Time Complexity : O(N)
	#Space Complexity : O(N)
	#BackTrackig
	def n_to_one(self,N):
		if N < 1:
			return 
		self.n_to_one(N - 1)
		print(N,end=",")

	#Time Complexity : O(N)
	#Space Complexity : O(N)
	def sum_of_n(self,N):
		if N == 0:
			return 1  

		return N + self.sum_of_n(N-1)

	#O(N)
	def factorial_of_n(self,N):
		if N == 0:
			return 1  

		return N * self.sum_of_n(N-1)

	def reverse_an_arr(self,arr):
		#O(N)
		# aux_arr = [0] * len(arr)
		# for i in range(len(arr)):
		# 	aux_arr[i] = arr[len(arr)-1 - i] 
		# print(aux_arr)
		
		p1 = 0
		p2 = len(arr) - 1
		while p1 < p2:
			arr[p1], arr[p2] = arr[p2], arr[p1]
			p1+=1
			p2-=1
		return arr
	
	def rev_arr_recur(self,l,r,arr):
		if l>=r:
			return
		arr[l], arr[r] = arr[r], arr[l]
		self.rev_arr_recur(l + 1, r -1, arr)
	#Time Complexity: O(N/2)
	#Space Complexity: O(n)
	def rev_arr_v1(self, i, arr, n):
		if i >= n//2:
			return
		arr[i],arr[n-i-1] = arr[n-i-1],arr[i]

		self.rev_arr_v1(i+1, arr, n)

	def palindrome_recur(self, i, n, s):
		if i>=n//2:
			return True
		
		if (s[i]) != s[n-i-1]:
			return False
		return self.palindrome_recur(i+1,n,s)
	def ispalindrome(self,s):
		l = 0
		r = len(s) - 1

		while l < r:
			if s[l] != s[r]:
				return False
			l+=1
			r-=1
		return True


	def fib(self,n):
		a, b = 0,1

		for _ in range(n):
			print(a,end=" ")
			a,b = b, a+b

	def fib_recur(self,n,arr):
		if n <=1:
			return n
		arr.append(n)
		return self.fib_recur(n-1,arr) + self.fib_recur(n-2,arr)

N = 5


sol = Solution()
# sol.n_to_1(N)
# print(sol.factorial_of_n(3))
arr = [1,2,3,4,5]
# print(sol.reverse_an_arr(arr))

# print(sol.palindrom("maloalam"))
# sol.n_to_one(N)
# sol.rev_arr_recur(0, len(arr)-1, arr)
# print(arr)
# sol.rev_arr_v1(0,arr,len(arr))
# print(arr)
s = "malayalam"
# print(sol.palindrome_recur(0,len(s),s))
arr = []

print(sol.fib_recur(5,arr))
print(arr)


