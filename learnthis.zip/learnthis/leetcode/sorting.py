
class Solution:
	def __init__(self,arr):
		print(f"Unsorted :{arr}")

	def selection_sort(self, arr):
		# Time complexity : O(N^ 2)
		# Space Complexity : O(1)
		# it like finding the minimum and swap value with the current index
		temp = 0
		n = len(arr)
		min_inx = 0

		for  i in range(n - 1):
			min_inx = i
			for j in range(i+1, n):
				if arr[j] < arr[min_inx]:
					min_inx = j

			arr[i], arr[min_inx] = arr[min_inx],arr[i]

		print("Selection  ",arr)
		return arr

	def bubble_sort(self, arr):
		# Time Complexity  : worst O(N^2) and 
		#best  if its sorted alreadyO(N)

		# Space Complexity : O(1)
		#Puting the max one to the
		
		n = len(arr)
		for i in range (n):
			swapped = False
			for j in range(n - i - 1):
				if arr[j] > arr[j+1]:
					arr[j], arr[j+1] = arr[j+1], arr[j]
					swapped = True
			if not swapped:
				break
				
		print("BubbleSort",arr)
		return arr




	## Base case: O(N) 
	#If the arr is sorted
	# Worst case : O(N^2)
	def insertion_sort(self, arr):
		
		for i in range(1,len(arr)):
			key = arr[i]
			j = i - 1
			while j >= 0 and arr[j] > key:
				arr[j + 1] = arr[j]
				j -= 1
			arr[j + 1] = key
			print(arr)
		print("Insertion Sort",arr)

	#Divide an Merge
	"""
	Merge sort splits the array into halves repeatedly, 
	creating about log n levels of recursion. At each level, 
	it processes all elements during merging, 
	taking O(n) time, so total time is O(n log n). and taking
	space of O(n)
	"""
	def merge(self, arr, low, mid, high):
		temp = []
		left, right = low, mid + 1

        # Merge both sorted halves
		while left <= mid and right <= high:
			if arr[left] <= arr[right]:
				temp.append(arr[left])
				left += 1
			else:
				temp.append(arr[right])
				right += 1

	    # Add remaining left elements
		while left <= mid:
			temp.append(arr[left])
			left += 1

	    # Add remaining right elements
		while right <= high:
			temp.append(arr[right])
			right += 1

	    # Copy sorted temp into original array
		for i in range(low, high + 1):
			arr[i] = temp[i - low]

	# Recursive merge sort
	def mergeSort(self, arr, low, high):
	    if low >= high:
	        return
	    mid = (low + high) // 2
	    self.mergeSort(arr, low, mid)
	    self.mergeSort(arr, mid + 1, high)
	    self.merge(arr, low, mid, high)

    # Pivot
	def quick_sort(self, arr, low, high):
		if low < high:
			pivotIndex = self.partition(arr, low, high)
			self.quick_sort(arr, low, pivotIndex - 1)
			self.quick_sort(arr, pivotIndex + 1, high)

	def partition(self, arr, low, high):
		pivot = arr[high]
		i = low - 1

		for j in range(low, high):
			if arr[j] <= pivot:
				i+=1
				arr[i], arr[j] = arr[j], arr[i]
		arr[i + 1], arr[high] = arr[high], arr[i + 1]
		print(arr)
		return i + 1
	
	def recursive_bubble_sort(self, arr, n):
		if n == 1:
			return

		swapped = False
		for j in range(n - 1):
			if arr[j] > arr[j+1]:
				arr[j], arr[j+1] = arr[j+1], arr[j]
				swapped = True
		if not swapped:
			return
		self.recursive_bubble_sort(arr, n - 1)

	def recursive_insert_sort(self, arr, n, i):

		if i == n:
			return

		key = arr[i]
		j = i - 1
		while j >= 0 and arr[j] > key:
			arr[j + 1] = arr[j]
			j -= 1
		arr[j + 1] = key
		print(arr)

		i+=1
		self.recursive_insert_sort(arr,n, i)


arr = [5, 7, 5, 4, 2, 1, 9]
# arr = [12,46,52,20,9,27,67,43,34,90,8,1]
sol = Solution(arr)

# sol.selection_sort(arr)

# sol.bubble_sort(arr)
# sol.insertion_sort(arr)
# sol.mergeSort(arr,0, len(arr) - 1)
# sol.quick_sort(arr, 0, len(arr) - 1)

# sol.recursive_bubble_sort(arr, len(arr))
sol.recursive_insert_sort(arr, len(arr), 1)
print(arr)







